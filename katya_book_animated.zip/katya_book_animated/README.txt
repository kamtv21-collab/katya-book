Файлы проекта:

index.html
assets/cover.png
assets/tanya-guardian.png
assets/coffee.mp4
assets/coffee-poster.jpg

Обложка: 1536 × 2048 px, соотношение 3:4.
Персонаж Тани: PNG с прозрачным фоном.
Видео: MP4 под названием coffee.mp4.
